// Use QUnit.assert to mimic node.assert.

module.exports = QUnit.assert;
